module Open3
  VERSION = "0.1.0"
end
